// --- Variáveis Globais do Jogo ---
let colheitadeira; // Nosso jogador
let campo; // O cenário que se move

let obstaculos = []; // Array para os obstáculos
let velocidadeJogo = 5; // Velocidade base de rolagem do campo e obstáculos
let gravidade = 0.5; // Força da gravidade para o pulo
let impulsoPulo = -10; // Força do pulo para cima

let pontuacao = 0;
let gameOver = false;

let minTempoEntreObstaculos = 80; // Mínimo de frames entre um obstáculo e outro
let maxTempoEntreObstaculos = 200; // Máximo de frames entre um obstáculo e outro
let proximoObstaculoTempo = 0;

let alturaChao; // Onde a colheitadeira "anda"

function setup() {
  createCanvas(800, 400); // Tela para o jogo
  alturaChao = height - 50; // Definindo o "chão" do jogo
  resetGame(); // Inicia o jogo
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Desenha o chão
  fill(160, 120, 50); // Cor de terra/campo
  rect(0, alturaChao, width, 50);

  if (!gameOver) {
    // Atualiza e mostra o campo
    campo.atualizar();
    campo.mostrar();

    // Atualiza e mostra a colheitadeira
    colheitadeira.atualizar();
    colheitadeira.mostrar();

    // Lógica dos obstáculos
    gerenciarObstaculos();

    // Aumenta a pontuação
    pontuacao += 1;
    // Aumenta a dificuldade gradualmente
    if (pontuacao % 500 === 0 && velocidadeJogo < 10) {
      velocidadeJogo += 0.5;
    }

  } else {
    // Tela de Game Over
    textAlign(CENTER, CENTER);
    textSize(50);
    fill(0);
    text("GAME OVER!", width / 2, height / 2 - 30);
    textSize(20);
    text("Pressione ESPAÇO ou ENTER para Reiniciar", width / 2, height / 2 + 20);
  }

  // Exibe a pontuação
  fill(0);
  textAlign(LEFT, TOP);
  textSize(18);
  text("Pontuação: " + floor(pontuacao / 10), 10, 10); // Divide por 10 para ter pontos mais "reais"
}

// --- Funções de Jogo ---
function resetGame() {
  colheitadeira = new Colheitadeira(100, alturaChao - 60); // Posiciona a colheitadeira
  campo = new Campo(alturaChao); // Inicializa o campo
  obstaculos = []; // Limpa os obstáculos
  pontuacao = 0;
  velocidadeJogo = 5; // Reinicia a velocidade
  gameOver = false;
  proximoObstaculoTempo = frameCount + random(minTempoEntreObstaculos, maxTempoEntreObstaculos);
}

function gerenciarObstaculos() {
  // Gera novos obstáculos
  if (frameCount > proximoObstaculoTempo) {
    obstaculos.push(new Obstaculo(width, alturaChao));
    proximoObstaculoTempo = frameCount + random(minTempoEntreObstaculos, maxTempoEntreObstaculos);
  }

  // Atualiza, mostra e verifica colisão dos obstáculos
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    let obs = obstaculos[i];
    obs.atualizar();
    obs.mostrar();

    // Verifica colisão
    if (colheitadeira.colide(obs)) {
      gameOver = true;
      // console.log("Colisão! Game Over."); // Para debug
      break; // Sai do loop para não verificar mais colisões após o game over
    }

    // Remove obstáculos que saíram da tela
    if (obs.x + obs.largura < 0) {
      obstaculos.splice(i, 1);
    }
  }
}

function keyPressed() {
  if (gameOver) {
    if (keyCode === 32 || keyCode === 13) { // Barra de espaço ou Enter
      resetGame();
    }
  } else {
    if (keyCode === 32 && colheitadeira.noChao) { // Barra de espaço para pular
      colheitadeira.pular();
    }
  }
}

// --- CLASSES ---

// Classe Colheitadeira (nosso jogador)
class Colheitadeira {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.largura = 80;
    this.altura = 60;
    this.velocidadeY = 0; // Velocidade vertical do pulo
    this.noChao = true; // Indica se está tocando o chão
  }

  mostrar() {
    // Corpo principal (amarelo)
    fill(255, 200, 0);
    rect(this.x, this.y, this.largura, this.altura);

    // Cabine
    fill(100);
    rect(this.x + this.largura * 0.7, this.y - 20, this.largura * 0.3, 20);

    // Plataforma de corte
    fill(200, 100, 0);
    rect(this.x - 20, this.y + 10, 20, this.altura - 20);

    // Rodas
    fill(50);
    ellipse(this.x + 15, this.y + this.altura, 25, 25);
    ellipse(this.x + this.largura - 15, this.y + this.altura, 25, 25);
  }

  atualizar() {
    this.y += this.velocidadeY; // Aplica a velocidade vertical
    this.velocidadeY += gravidade; // Aplica a gravidade

    // Se atingir o chão
    if (this.y + this.altura >= alturaChao) {
      this.y = alturaChao - this.altura; // Volta para o chão
      this.velocidadeY = 0; // Zera a velocidade vertical
      this.noChao = true; // Está no chão
    }
  }

  pular() {
    this.velocidadeY = impulsoPulo; // Aplica o impulso de pulo
    this.noChao = false; // Não está mais no chão
  }

  // Verifica colisão com um obstáculo
  colide(obstaculo) {
    // Simplificando a colisão para retângulos
    return (
      this.x < obstaculo.x + obstaculo.largura &&
      this.x + this.largura > obstaculo.x &&
      this.y < obstaculo.y + obstaculo.altura &&
      this.y + this.altura > obstaculo.y
    );
  }
}

// Classe Obstaculo
class Obstaculo {
  constructor(x, yChao) {
    this.x = x;
    this.largura = random(20, 40); // Tamanho variado do obstáculo
    this.altura = random(20, 40);
    this.y = yChao - this.altura; // Posiciona no chão
    this.cor = color(random(80, 150)); // Tons de cinza/marrom
  }

  mostrar() {
    fill(this.cor);
    rect(this.x, this.y, this.largura, this.altura); // Desenha como um retângulo simples
  }

  atualizar() {
    this.x -= velocidadeJogo; // Move o obstáculo para a esquerda
  }
}

// Classe Campo (para as plantas de trigo que dão a sensação de movimento)
class Campo {
  constructor(yChao) {
    this.plantas = [];
    this.yChao = yChao;
    // Gera as plantas iniciais do campo
    for (let i = 0; i < 100; i++) {
      this.plantas.push({
        x: random(width),
        y: random(yChao + 5, height - 10),
        tamanho: random(5, 15),
        largura: random(1, 3)
      });
    }
  }

  mostrar() {
    fill(205, 133, 63); // Cor de trigo
    for (let planta of this.plantas) {
      rect(planta.x, planta.y - planta.tamanho, planta.largura, planta.tamanho);
    }
  }

  atualizar() {
    for (let planta of this.plantas) {
      planta.x -= velocidadeJogo; // Move as plantas para a esquerda
      // Reposiciona a planta quando ela sai da tela
      if (planta.x < 0) {
        planta.x = width + random(50);
        planta.y = random(this.yChao + 5, height - 10);
      }
    }
  }
}                                     
